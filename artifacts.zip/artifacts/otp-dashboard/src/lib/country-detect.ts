const DIAL_MAP: [string, string][] = [
  ["+1268","🇦🇬 Antigua & Barbuda"],["+1246","🇧🇧 Barbados"],["+1242","🇧🇸 Bahamas"],
  ["+1441","🇧🇲 Bermuda"],["+1345","🇰🇾 Cayman Islands"],["+1767","🇩🇲 Dominica"],
  ["+1809","🇩🇴 Dominican Republic"],["+1829","🇩🇴 Dominican Republic"],["+1849","🇩🇴 Dominican Republic"],
  ["+1473","🇬🇩 Grenada"],["+1876","🇯🇲 Jamaica"],["+1787","🇵🇷 Puerto Rico"],
  ["+1939","🇵🇷 Puerto Rico"],["+1869","🇰🇳 St Kitts & Nevis"],["+1758","🇱🇨 Saint Lucia"],
  ["+1784","🇻🇨 Saint Vincent"],["+1868","🇹🇹 Trinidad & Tobago"],["+1340","🇻🇮 US Virgin Islands"],
  ["+880","🇧🇩 Bangladesh"],["+886","🇹🇼 Taiwan"],
  ["+7840","🇬🇪 Abkhazia"],["+7","🇷🇺 Russia"],
  ["+20","🇪🇬 Egypt"],["+212","🇲🇦 Morocco"],["+213","🇩🇿 Algeria"],["+216","🇹🇳 Tunisia"],
  ["+218","🇱🇾 Libya"],["+220","🇬🇲 Gambia"],["+221","🇸🇳 Senegal"],["+222","🇲🇷 Mauritania"],
  ["+223","🇲🇱 Mali"],["+224","🇬🇳 Guinea"],["+225","🇨🇮 Ivory Coast"],["+226","🇧🇫 Burkina Faso"],
  ["+227","🇳🇪 Niger"],["+228","🇹🇬 Togo"],["+229","🇧🇯 Benin"],["+230","🇲🇺 Mauritius"],
  ["+231","🇱🇷 Liberia"],["+232","🇸🇱 Sierra Leone"],["+233","🇬🇭 Ghana"],["+234","🇳🇬 Nigeria"],
  ["+235","🇹🇩 Chad"],["+237","🇨🇲 Cameroon"],["+238","🇨🇻 Cape Verde"],["+240","🇬🇶 Equatorial Guinea"],
  ["+241","🇬🇦 Gabon"],["+242","🇨🇬 Congo"],["+243","🇨🇩 DR Congo"],["+244","🇦🇴 Angola"],
  ["+245","🇬🇼 Guinea-Bissau"],["+248","🇸🇨 Seychelles"],["+249","🇸🇩 Sudan"],["+250","🇷🇼 Rwanda"],
  ["+251","🇪🇹 Ethiopia"],["+252","🇸🇴 Somalia"],["+253","🇩🇯 Djibouti"],["+254","🇰🇪 Kenya"],
  ["+255","🇹🇿 Tanzania"],["+256","🇺🇬 Uganda"],["+257","🇧🇮 Burundi"],["+258","🇲🇿 Mozambique"],
  ["+260","🇿🇲 Zambia"],["+261","🇲🇬 Madagascar"],["+263","🇿🇼 Zimbabwe"],["+264","🇳🇦 Namibia"],
  ["+265","🇲🇼 Malawi"],["+266","🇱🇸 Lesotho"],["+267","🇧🇼 Botswana"],["+268","🇸🇿 Eswatini"],
  ["+27","🇿🇦 South Africa"],["+290","🇸🇭 Saint Helena"],["+291","🇪🇷 Eritrea"],
  ["+30","🇬🇷 Greece"],["+31","🇳🇱 Netherlands"],["+32","🇧🇪 Belgium"],["+33","🇫🇷 France"],
  ["+34","🇪🇸 Spain"],["+350","🇬🇮 Gibraltar"],["+351","🇵🇹 Portugal"],["+352","🇱🇺 Luxembourg"],
  ["+353","🇮🇪 Ireland"],["+354","🇮🇸 Iceland"],["+355","🇦🇱 Albania"],["+356","🇲🇹 Malta"],
  ["+357","🇨🇾 Cyprus"],["+358","🇫🇮 Finland"],["+359","🇧🇬 Bulgaria"],["+36","🇭🇺 Hungary"],
  ["+370","🇱🇹 Lithuania"],["+371","🇱🇻 Latvia"],["+372","🇪🇪 Estonia"],["+373","🇲🇩 Moldova"],
  ["+374","🇦🇲 Armenia"],["+375","🇧🇾 Belarus"],["+380","🇺🇦 Ukraine"],["+381","🇷🇸 Serbia"],
  ["+382","🇲🇪 Montenegro"],["+385","🇭🇷 Croatia"],["+386","🇸🇮 Slovenia"],["+387","🇧🇦 Bosnia"],
  ["+389","🇲🇰 N. Macedonia"],["+39","🇮🇹 Italy"],["+40","🇷🇴 Romania"],["+41","🇨🇭 Switzerland"],
  ["+420","🇨🇿 Czech Republic"],["+421","🇸🇰 Slovakia"],["+43","🇦🇹 Austria"],["+44","🇬🇧 United Kingdom"],
  ["+45","🇩🇰 Denmark"],["+46","🇸🇪 Sweden"],["+47","🇳🇴 Norway"],["+48","🇵🇱 Poland"],
  ["+49","🇩🇪 Germany"],
  ["+501","🇧🇿 Belize"],["+502","🇬🇹 Guatemala"],["+503","🇸🇻 El Salvador"],["+504","🇭🇳 Honduras"],
  ["+505","🇳🇮 Nicaragua"],["+506","🇨🇷 Costa Rica"],["+507","🇵🇦 Panama"],["+509","🇭🇹 Haiti"],
  ["+51","🇵🇪 Peru"],["+52","🇲🇽 Mexico"],["+53","🇨🇺 Cuba"],["+54","🇦🇷 Argentina"],
  ["+55","🇧🇷 Brazil"],["+56","🇨🇱 Chile"],["+57","🇨🇴 Colombia"],["+58","🇻🇪 Venezuela"],
  ["+591","🇧🇴 Bolivia"],["+592","🇬🇾 Guyana"],["+593","🇪🇨 Ecuador"],["+595","🇵🇾 Paraguay"],
  ["+597","🇸🇷 Suriname"],["+598","🇺🇾 Uruguay"],
  ["+60","🇲🇾 Malaysia"],["+61","🇦🇺 Australia"],["+62","🇮🇩 Indonesia"],["+63","🇵🇭 Philippines"],
  ["+64","🇳🇿 New Zealand"],["+65","🇸🇬 Singapore"],["+66","🇹🇭 Thailand"],
  ["+670","🇹🇱 East Timor"],["+673","🇧🇳 Brunei"],["+675","🇵🇬 Papua New Guinea"],
  ["+679","🇫🇯 Fiji"],["+689","🇵🇫 French Polynesia"],
  ["+81","🇯🇵 Japan"],["+82","🇰🇷 South Korea"],["+84","🇻🇳 Vietnam"],
  ["+850","🇰🇵 North Korea"],["+852","🇭🇰 Hong Kong"],["+853","🇲🇴 Macau"],
  ["+855","🇰🇭 Cambodia"],["+856","🇱🇦 Laos"],["+86","🇨🇳 China"],
  ["+90","🇹🇷 Turkey"],["+91","🇮🇳 India"],["+92","🇵🇰 Pakistan"],["+93","🇦🇫 Afghanistan"],
  ["+94","🇱🇰 Sri Lanka"],["+95","🇲🇲 Myanmar"],
  ["+960","🇲🇻 Maldives"],["+961","🇱🇧 Lebanon"],["+962","🇯🇴 Jordan"],["+963","🇸🇾 Syria"],
  ["+964","🇮🇶 Iraq"],["+965","🇰🇼 Kuwait"],["+966","🇸🇦 Saudi Arabia"],["+967","🇾🇪 Yemen"],
  ["+968","🇴🇲 Oman"],["+970","🇵🇸 Palestine"],["+971","🇦🇪 UAE"],["+972","🇮🇱 Israel"],
  ["+973","🇧🇭 Bahrain"],["+974","🇶🇦 Qatar"],["+975","🇧🇹 Bhutan"],["+976","🇲🇳 Mongolia"],
  ["+977","🇳🇵 Nepal"],["+98","🇮🇷 Iran"],
  ["+992","🇹🇯 Tajikistan"],["+993","🇹🇲 Turkmenistan"],["+994","🇦🇿 Azerbaijan"],
  ["+995","🇬🇪 Georgia"],["+996","🇰🇬 Kyrgyzstan"],["+998","🇺🇿 Uzbekistan"],
  ["+1","🇺🇸 USA"],
];

const SORTED = DIAL_MAP.sort((a, b) => b[0].length - a[0].length);

export function detectCountry(rawNumber: string): string {
  let num = rawNumber.replace(/[\s\-().]/g, "");
  if (!num.startsWith("+")) {
    if (num.startsWith("00")) num = "+" + num.slice(2);
    else if (num.length > 10) num = "+" + num;
  }
  for (const [code, country] of SORTED) {
    if (num.startsWith(code)) return country;
  }
  return "🌐 Unknown";
}
