import { useAdminDashboard, useAdminAuth, useLiveOtps, useUploadNumbers, useNumberCountries, useNumbersByCountry, useDeleteNumber, useDeleteNumbersByCountry, useSendBroadcast, useClearBroadcast, useActiveBroadcast } from "@/hooks/use-api";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { LogOut, Plus, Trash2, ShieldCheck, Activity, Globe, Loader2, Upload, FileText, CheckCircle2, Phone, ChevronDown, Megaphone, Send, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { useRef, useState } from "react";

const formSchema = z.object({
  number: z.string().min(1, "Number is required"),
  service: z.string().min(1, "Service is required"),
  code: z.string().min(1, "Code is required"),
  country: z.string().default("🇧🇩 Bangladesh")
});

type FormValues = z.infer<typeof formSchema>;

export default function AdminDashboard() {
  const { stats, create, remove } = useAdminDashboard();
  const { token, logout } = useAdminAuth();
  const { data: otps, isLoading } = useLiveOtps(200);
  const upload = useUploadNumbers();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedLines, setUploadedLines] = useState<string[]>([]);
  const [uploadFileName, setUploadFileName] = useState<string | null>(null);
  const [uploadResult, setUploadResult] = useState<{ inserted: number; skipped: number; total: number } | null>(null);

  // Broadcast
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const sendBroadcast = useSendBroadcast();
  const clearBroadcast = useClearBroadcast();
  const { data: activeBroadcast } = useActiveBroadcast();

  // Numbers management
  const [numCountryOpen, setNumCountryOpen] = useState(false);
  const [selectedNumCountry, setSelectedNumCountry] = useState<string | null>(null);
  const [confirmDeleteCountry, setConfirmDeleteCountry] = useState(false);
  const { data: numCountries } = useNumberCountries();
  const { data: managedNumbers, isLoading: managedLoading } = useNumbersByCountry(selectedNumCountry);
  const deleteNumber = useDeleteNumber();
  const deleteByCountry = useDeleteNumbersByCountry();

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadFileName(file.name);
    setUploadResult(null);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const lines = text
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l.length >= 5);
      setUploadedLines(lines);
    };
    reader.readAsText(file);
  }

  async function handleUpload() {
    if (uploadedLines.length === 0) return;
    const result = await upload.mutateAsync(uploadedLines);
    setUploadResult(result);
    setUploadedLines([]);
    setUploadFileName(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      number: "",
      service: "",
      code: "",
      country: "🇧🇩 Bangladesh"
    }
  });

  const onSubmit = form.handleSubmit((data) => {
    create.mutate({ data: { ...data, adminToken: token || "" } }, {
      onSuccess: () => {
        form.reset({ ...form.getValues(), code: "", number: "" }); // keep country/service for speed
      }
    });
  });

  return (
    <div className="min-h-screen bg-background pb-20 relative">
      <div className="absolute top-0 right-0 w-[600px] h-[400px] bg-primary/10 blur-[150px] pointer-events-none rounded-full" />
      
      {/* Admin Navbar */}
      <nav className="border-b border-border/50 bg-card/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center border border-primary/30">
              <ShieldCheck className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-display font-bold text-foreground leading-none">Admin Center</h1>
              <Link href="/" className="text-xs text-primary hover:underline font-medium">← Back to Dashboard</Link>
            </div>
          </div>
          
          <button 
            onClick={logout}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 font-semibold transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 relative z-10">
        
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-card border border-border p-6 rounded-3xl shadow-lg relative overflow-hidden group">
            <div className="absolute right-[-20px] top-[-20px] opacity-10 group-hover:opacity-20 transition-opacity"><Activity className="w-32 h-32" /></div>
            <div className="text-muted-foreground text-sm font-semibold uppercase tracking-widest mb-2 relative z-10">Total OTPs</div>
            <div className="text-5xl font-display font-bold text-foreground relative z-10">{stats.data?.totalOtps || 0}</div>
          </motion.div>
          
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-primary/10 border border-primary/20 p-6 rounded-3xl shadow-lg relative overflow-hidden group">
             <div className="absolute right-[-20px] top-[-20px] text-primary opacity-10 group-hover:opacity-20 transition-opacity"><Globe className="w-32 h-32" /></div>
            <div className="text-primary/80 text-sm font-semibold uppercase tracking-widest mb-2 relative z-10">Added Today</div>
            <div className="text-5xl font-display font-bold text-primary relative z-10">{stats.data?.todayOtps || 0}</div>
          </motion.div>
          
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card border border-border p-6 rounded-3xl shadow-lg relative overflow-hidden">
            <div className="text-muted-foreground text-sm font-semibold uppercase tracking-widest mb-2">Last Update</div>
            <div className="text-2xl font-mono font-medium text-foreground mt-4">
              {stats.data?.lastAddedAt ? format(new Date(stats.data.lastAddedAt), "HH:mm:ss") : "Never"}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {stats.data?.lastAddedAt ? format(new Date(stats.data.lastAddedAt), "MMM do, yyyy") : ""}
            </div>
          </motion.div>
        </div>

        {/* Broadcast Message */}
        <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-3xl p-6 sm:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.3)] mb-10">
          <h2 className="text-2xl font-bold mb-2 flex items-center gap-3">
            <Megaphone className="w-6 h-6 text-yellow-400" /> Broadcast Message
          </h2>
          <p className="text-sm text-muted-foreground mb-5">
            Send a message that appears as a banner on the public dashboard for all users.
          </p>

          {/* Active broadcast preview */}
          <AnimatePresence>
            {activeBroadcast && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="flex items-start justify-between gap-3 p-4 mb-4 bg-yellow-500/10 border border-yellow-500/30 rounded-2xl"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="flex items-center gap-1.5 shrink-0 mt-0.5">
                    <motion.div
                      animate={{ opacity: [1, 0.3, 1] }}
                      transition={{ duration: 1.2, repeat: Infinity }}
                      className="w-2 h-2 rounded-full bg-yellow-400"
                    />
                    <span className="text-xs font-black text-yellow-400 uppercase tracking-widest">Live</span>
                  </div>
                  <p className="text-sm text-foreground font-medium break-words">{activeBroadcast.message}</p>
                </div>
                <button
                  onClick={() => clearBroadcast.mutate(activeBroadcast.id)}
                  disabled={clearBroadcast.isPending}
                  className="p-1.5 rounded-lg bg-yellow-500/20 text-yellow-400 hover:bg-destructive/20 hover:text-destructive transition-all shrink-0 disabled:opacity-40"
                  title="Clear broadcast"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex gap-3">
            <textarea
              value={broadcastMsg}
              onChange={(e) => setBroadcastMsg(e.target.value)}
              placeholder="Type your message to broadcast to all users..."
              rows={2}
              className="flex-1 bg-background border border-border rounded-xl px-4 py-3 text-foreground focus:ring-2 focus:ring-yellow-500/40 focus:border-yellow-500/50 outline-none transition-all placeholder:text-muted-foreground/40 resize-none text-sm"
            />
            <button
              onClick={async () => {
                if (!broadcastMsg.trim()) return;
                await sendBroadcast.mutateAsync(broadcastMsg.trim());
                setBroadcastMsg("");
              }}
              disabled={!broadcastMsg.trim() || sendBroadcast.isPending}
              className="px-5 py-3 rounded-xl bg-yellow-500 hover:bg-yellow-400 disabled:opacity-40 disabled:cursor-not-allowed text-black font-black uppercase tracking-wide transition-all flex items-center gap-2 self-stretch shadow-[0_5px_20px_rgba(234,179,8,0.3)]"
            >
              {sendBroadcast.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Add Entry Form */}
        <div className="bg-card border border-border rounded-3xl p-6 sm:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.3)] mb-10">
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
            <Plus className="w-6 h-6 text-primary" /> Create New Entry
          </h2>
          
          <form onSubmit={onSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
            <div className="lg:col-span-1">
              <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 block">Phone Number</label>
              <input 
                {...form.register("number")} 
                className="w-full bg-background border border-border rounded-xl px-4 py-3 font-mono text-foreground focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all placeholder:text-muted-foreground/30" 
                placeholder="+1 234 567 8900" 
              />
              {form.formState.errors.number && <p className="text-xs text-destructive mt-1">{form.formState.errors.number.message}</p>}
            </div>
            <div className="lg:col-span-1">
              <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 block">Service</label>
              <input 
                {...form.register("service")} 
                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-foreground focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all placeholder:text-muted-foreground/30" 
                placeholder="WhatsApp" 
              />
              {form.formState.errors.service && <p className="text-xs text-destructive mt-1">{form.formState.errors.service.message}</p>}
            </div>
            <div className="lg:col-span-1">
              <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 block">OTP Code</label>
              <input 
                {...form.register("code")} 
                className="w-full bg-background border border-border rounded-xl px-4 py-3 font-mono font-bold text-primary focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all placeholder:text-primary/30" 
                placeholder="123456" 
              />
              {form.formState.errors.code && <p className="text-xs text-destructive mt-1">{form.formState.errors.code.message}</p>}
            </div>
            <div className="lg:col-span-1">
              <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 block">Country</label>
              <input 
                {...form.register("country")} 
                className="w-full bg-background border border-border rounded-xl px-4 py-3 text-foreground focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all placeholder:text-muted-foreground/30" 
                placeholder="🇧🇩 Bangladesh" 
              />
            </div>
            <div className="lg:col-span-1 flex items-end">
              <button 
                type="submit" 
                disabled={create.isPending} 
                className="w-full h-[50px] bg-primary hover:bg-primary/90 text-primary-foreground font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-[0_5px_20px_rgba(79,70,229,0.3)] disabled:opacity-50"
              >
                {create.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Plus className="w-5 h-5" /> Push to Live</>}
              </button>
            </div>
          </form>
        </div>

        {/* Upload Numbers */}
        <div className="bg-card border border-border rounded-3xl p-6 sm:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.3)] mb-10">
          <h2 className="text-2xl font-bold mb-2 flex items-center gap-3">
            <Upload className="w-6 h-6 text-cyan-400" /> Upload Numbers (TXT)
          </h2>
          <p className="text-sm text-muted-foreground mb-6">
            Upload a .txt file with one phone number per line. Country is detected automatically from the dial code.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 items-start">
            <label
              className="flex-1 flex flex-col items-center justify-center gap-3 border-2 border-dashed border-border hover:border-cyan-500/50 rounded-2xl p-8 cursor-pointer transition-all bg-background/40 hover:bg-cyan-500/5 group"
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".txt,text/plain"
                className="hidden"
                onChange={handleFileChange}
              />
              <FileText className="w-10 h-10 text-muted-foreground group-hover:text-cyan-400 transition-colors" />
              {uploadFileName ? (
                <div className="text-center">
                  <div className="font-semibold text-foreground">{uploadFileName}</div>
                  <div className="text-sm text-cyan-400 font-bold mt-1">{uploadedLines.length} numbers parsed</div>
                </div>
              ) : (
                <div className="text-center">
                  <div className="font-semibold text-foreground">Click to select .txt file</div>
                  <div className="text-xs text-muted-foreground mt-1">One phone number per line</div>
                </div>
              )}
            </label>

            <div className="flex flex-col gap-3 w-full sm:w-auto">
              <button
                onClick={handleUpload}
                disabled={uploadedLines.length === 0 || upload.isPending}
                className="px-8 py-4 rounded-2xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 disabled:cursor-not-allowed text-black font-black uppercase tracking-wider transition-all flex items-center gap-2 shadow-[0_5px_20px_rgba(6,182,212,0.3)] whitespace-nowrap"
              >
                {upload.isPending ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> Uploading...</>
                ) : (
                  <><Upload className="w-5 h-5" /> Upload Numbers</>
                )}
              </button>

              <AnimatePresence>
                {uploadResult && (
                  <motion.div
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="flex items-start gap-3 p-4 bg-[#0d1f14] border border-[#33aa66]/30 rounded-2xl"
                  >
                    <CheckCircle2 className="w-5 h-5 text-[#33aa66] mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <div className="font-bold text-[#33aa66]">Upload complete!</div>
                      <div className="text-muted-foreground mt-1">
                        {uploadResult.inserted} inserted · {uploadResult.skipped} skipped · {uploadResult.total} total
                      </div>
                      <div className="text-xs text-muted-foreground/70 mt-1">Countries auto-detected from dial codes</div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {upload.isError && (
                <div className="p-4 bg-destructive/10 border border-destructive/30 rounded-2xl text-destructive text-sm font-medium">
                  Upload failed. Make sure you are logged in as admin.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Manage Numbers */}
        <div className="bg-card border border-border rounded-3xl p-6 sm:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.3)] mb-10">
          <h2 className="text-2xl font-bold mb-2 flex items-center gap-3">
            <Phone className="w-6 h-6 text-primary" /> Manage Numbers
          </h2>
          <p className="text-sm text-muted-foreground mb-5">
            Select a country to view and delete uploaded numbers.
          </p>

          {/* Country picker */}
          {!numCountries || numCountries.length === 0 ? (
            <div className="py-5 text-center text-muted-foreground text-sm bg-secondary/10 rounded-xl border border-border">
              No numbers uploaded yet.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative">
                <button
                  onClick={() => setNumCountryOpen(!numCountryOpen)}
                  className="w-full flex items-center justify-between bg-background border border-border rounded-xl px-4 py-3 text-left hover:border-primary/50 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                >
                  <span className={selectedNumCountry ? "text-foreground font-medium" : "text-muted-foreground"}>
                    {selectedNumCountry ?? "Choose a country to manage..."}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${numCountryOpen ? "rotate-180" : ""}`} />
                </button>

                <AnimatePresence>
                  {numCountryOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      className="absolute top-full mt-2 left-0 right-0 z-20 bg-[#0e1627] border border-border rounded-xl shadow-xl overflow-hidden max-h-60 overflow-y-auto"
                    >
                      {numCountries.map((c) => (
                        <button
                          key={c.country}
                          onClick={() => { setSelectedNumCountry(c.country); setNumCountryOpen(false); setConfirmDeleteCountry(false); }}
                          className={`w-full flex items-center justify-between px-4 py-3 text-left hover:bg-primary/10 transition-colors border-b border-border/30 last:border-0 ${selectedNumCountry === c.country ? "bg-primary/10 text-primary" : "text-foreground"}`}
                        >
                          <span className="font-medium">{c.country}</span>
                          <span className="text-xs text-muted-foreground bg-secondary/80 px-2 py-0.5 rounded-full">
                            {c.count} number{c.count !== 1 ? "s" : ""}
                          </span>
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Numbers list with delete */}
              {selectedNumCountry && (
                <div>
                  {managedLoading ? (
                    <div className="flex items-center gap-2 text-muted-foreground text-sm py-4">
                      <Loader2 className="w-4 h-4 animate-spin" /> Loading numbers...
                    </div>
                  ) : !managedNumbers || managedNumbers.length === 0 ? (
                    <div className="py-6 text-center text-muted-foreground text-sm bg-secondary/10 rounded-xl border border-border">
                      No numbers found for this country.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
                      {/* Header row with count + Delete All */}
                      <div className="flex items-center justify-between mb-3 px-1">
                        <span className="text-xs text-muted-foreground font-medium">
                          {managedNumbers.length} number{managedNumbers.length !== 1 ? "s" : ""} in {selectedNumCountry}
                        </span>

                        {!confirmDeleteCountry ? (
                          <button
                            onClick={() => setConfirmDeleteCountry(true)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive hover:text-white text-xs font-bold uppercase tracking-wide transition-all"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> Delete All
                          </button>
                        ) : (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="flex items-center gap-2"
                          >
                            <span className="text-xs text-destructive font-semibold">Delete all {managedNumbers.length} numbers?</span>
                            <button
                              onClick={async () => {
                                await deleteByCountry.mutateAsync(selectedNumCountry);
                                setConfirmDeleteCountry(false);
                                setSelectedNumCountry(null);
                              }}
                              disabled={deleteByCountry.isPending}
                              className="px-3 py-1.5 rounded-lg bg-destructive text-white text-xs font-black uppercase tracking-wide hover:bg-destructive/80 disabled:opacity-50 transition-all flex items-center gap-1"
                            >
                              {deleteByCountry.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : null}
                              Yes, delete
                            </button>
                            <button
                              onClick={() => setConfirmDeleteCountry(false)}
                              className="px-3 py-1.5 rounded-lg bg-secondary text-foreground text-xs font-bold uppercase tracking-wide hover:bg-secondary/60 transition-all"
                            >
                              Cancel
                            </button>
                          </motion.div>
                        )}
                      </div>
                      <AnimatePresence>
                        {managedNumbers.map((n) => (
                          <motion.div
                            key={n.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 10, height: 0, marginBottom: 0 }}
                            transition={{ duration: 0.2 }}
                            className="flex items-center justify-between gap-3 p-3 rounded-xl bg-background border border-border/60 hover:border-border group"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <span className="font-mono font-bold text-sm text-foreground truncate">
                                {n.number}
                              </span>
                              {n.otpCode && (
                                <span className="text-xs font-mono font-black text-[#33aa66] bg-[#33aa66]/10 border border-[#33aa66]/20 px-2 py-0.5 rounded-full shrink-0">
                                  {n.otpCode}
                                </span>
                              )}
                            </div>
                            <button
                              onClick={() => deleteNumber.mutate(n.id)}
                              disabled={deleteNumber.isPending}
                              className="p-2 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive hover:text-white transition-all disabled:opacity-40 shrink-0 opacity-0 group-hover:opacity-100 focus:opacity-100"
                              title="Delete number"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </motion.div>
                        ))}
                      </AnimatePresence>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Database Table */}
        <div className="bg-card border border-border rounded-3xl p-6 sm:p-8 shadow-xl">
          <h2 className="text-2xl font-bold mb-6">Recent Database Entries</h2>
          
          <div className="overflow-x-auto rounded-xl">
            <table className="w-full text-left border-collapse min-w-[640px]">
              <thead>
                <tr className="border-b border-border text-xs font-bold text-muted-foreground uppercase tracking-widest">
                  <th className="pb-4 pl-3 pr-4 font-medium whitespace-nowrap">Time</th>
                  <th className="pb-4 pr-6 font-medium whitespace-nowrap">Phone Number</th>
                  <th className="pb-4 pr-6 font-medium whitespace-nowrap">Service</th>
                  <th className="pb-4 pr-6 font-medium whitespace-nowrap">Code</th>
                  <th className="pb-4 pr-6 font-medium whitespace-nowrap">Country</th>
                  <th className="pb-4 pr-3 text-right font-medium whitespace-nowrap">Actions</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence>
                  {otps?.map((otp) => (
                    <motion.tr 
                      key={otp.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="border-b border-border/50 hover:bg-secondary/30 transition-colors group"
                    >
                      <td className="py-3 pl-3 pr-4 text-sm text-muted-foreground whitespace-nowrap">
                        {format(new Date(otp.createdAt), "HH:mm:ss")}
                      </td>
                      <td className="py-3 pr-6 font-mono text-sm font-semibold text-foreground whitespace-nowrap">
                        {otp.number}
                      </td>
                      <td className="py-3 pr-6 text-sm font-medium text-foreground whitespace-nowrap">
                        {otp.service}
                      </td>
                      <td className="py-3 pr-6 font-mono font-bold text-primary whitespace-nowrap tracking-wider">
                        {otp.code}
                      </td>
                      <td className="py-3 pr-6 text-sm text-muted-foreground whitespace-nowrap">
                        {otp.country}
                      </td>
                      <td className="py-3 pr-3 text-right">
                        <button 
                          onClick={() => remove.mutate({ id: otp.id })}
                          disabled={remove.isPending}
                          className="p-2 rounded-lg bg-destructive/10 text-destructive opacity-0 group-hover:opacity-100 hover:bg-destructive hover:text-white transition-all focus:opacity-100 disabled:opacity-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </motion.tr>
                  ))}
                  
                  {(!otps || otps.length === 0) && !isLoading && (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-muted-foreground">
                        No entries found in database. Add some using the form above.
                      </td>
                    </tr>
                  )}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        </div>

      </main>
    </div>
  );
}
