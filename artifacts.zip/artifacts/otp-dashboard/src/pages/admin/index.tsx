import { useAdminAuth } from "@/hooks/use-api";
import Login from "./Login";
import AdminDashboard from "./AdminDashboard";

export default function AdminPage() {
  const { token } = useAdminAuth();
  
  if (!token) {
    return <Login />;
  }
  
  return <AdminDashboard />;
}
