import { useState, useEffect, useRef } from "react";
import { useLiveOtps, useActiveBroadcast } from "@/hooks/use-api";
import { SignalBars } from "@/components/SignalBars";
import GetNumberModal from "@/components/GetNumberModal";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldCheck, Zap, Globe, Clock, Lock, Send, Megaphone, X } from "lucide-react";
import { Link } from "wouter";

function maskNumber(num: string): string {
  if (num.length <= 8) return num;
  return num.slice(0, 4) + "****" + num.slice(-4);
}

function playDing() {
  try {
    const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(660, ctx.currentTime + 0.15);
    gain.gain.setValueAtTime(0.35, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.6);
  } catch {
    // Audio not available
  }
}

export default function Dashboard() {
  const { data: otps, isLoading, isError } = useLiveOtps(100);
  const { data: broadcast } = useActiveBroadcast();
  const [showGetNumber, setShowGetNumber] = useState(false);
  const [dismissedBroadcast, setDismissedBroadcast] = useState<number | null>(null);
  const prevOtpIds = useRef<Set<number>>(new Set());
  const hasInteracted = useRef(false);

  // Track user interaction so AudioContext is allowed
  useEffect(() => {
    const mark = () => { hasInteracted.current = true; };
    window.addEventListener("click", mark, { once: true });
    window.addEventListener("keydown", mark, { once: true });
    return () => {
      window.removeEventListener("click", mark);
      window.removeEventListener("keydown", mark);
    };
  }, []);

  // Ding when new OTPs arrive
  useEffect(() => {
    if (!otps || otps.length === 0) return;
    const currentIds = new Set(otps.map((o) => o.id));
    const isFirstLoad = prevOtpIds.current.size === 0;
    if (!isFirstLoad && hasInteracted.current) {
      const hasNew = otps.some((o) => !prevOtpIds.current.has(o.id));
      if (hasNew) playDing();
    }
    prevOtpIds.current = currentIds;
  }, [otps]);

  const stats = [
    { label: "Secure", value: "100%", sub: "End-to-end encryption", icon: ShieldCheck },
    { label: "Delivery", value: "Instant", sub: "< 1s average latency", icon: Zap },
    { label: "Coverage", value: "Global", sub: "190+ supported countries", icon: Globe },
    { label: "Total OTPs", value: otps?.length || 0, sub: "24/7 Availability", icon: Clock },
  ];

  const showBroadcast = broadcast && broadcast.active && dismissedBroadcast !== broadcast.id;

  return (
    <div className="min-h-screen pb-20 relative">
      {/* Decorative top blur */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-[1000px] h-[300px] bg-primary/15 blur-[120px] pointer-events-none rounded-full" />

      {/* Broadcast Banner */}
      <AnimatePresence>
        {showBroadcast && (
          <motion.div
            initial={{ opacity: 0, y: -40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -40 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="relative z-50 w-full bg-gradient-to-r from-yellow-500/90 to-orange-500/90 backdrop-blur-sm border-b border-yellow-400/30 shadow-[0_4px_30px_rgba(234,179,8,0.3)]"
          >
            <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
              <div className="flex items-center gap-2 shrink-0">
                <motion.div
                  animate={{ rotate: [-10, 10, -10] }}
                  transition={{ duration: 0.6, repeat: Infinity, repeatDelay: 2 }}
                >
                  <Megaphone className="w-5 h-5 text-black" />
                </motion.div>
                <span className="text-xs font-black text-black/80 uppercase tracking-widest hidden sm:block">Broadcast</span>
              </div>
              <p className="flex-1 text-sm font-semibold text-black leading-snug">{broadcast!.message}</p>
              <button
                onClick={() => setDismissedBroadcast(broadcast!.id)}
                className="p-1 rounded-full hover:bg-black/10 text-black/70 hover:text-black transition-colors shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="pt-16 pb-12 px-4 max-w-6xl mx-auto relative z-10 flex flex-col items-center sm:items-start text-center sm:text-left">
        <div className="flex items-center gap-3 mb-6 flex-wrap justify-center sm:justify-start">
          <div className="px-3 py-1 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-bold tracking-widest uppercase">
            v2.0 Beta
          </div>
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-red-500 text-xs font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(239,68,68,0.2)]">
            <motion.div
              animate={{ opacity: [1, 0.4, 1], scale: [1, 1.2, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]"
            />
            LIVE
          </div>
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-white/90 to-primary/60 tracking-tight leading-tight">
          PREMIUM NUMBER OTP
        </h1>
        
        <div className="mt-4 flex items-center gap-3 flex-wrap justify-center sm:justify-start">
          <span className="text-lg text-primary font-medium tracking-wide">
            ⚡ REAL-TIME DATA FEED ⚡
          </span>
          <span className="px-3 py-1 rounded border border-blue-500/30 bg-blue-500/20 text-blue-400 text-sm font-bold shadow-[0_0_15px_rgba(59,130,246,0.15)]">
            🇧🇩 Bangladesh
          </span>
        </div>
      </header>

      {/* Stats Row */}
      <section className="px-4 max-w-6xl mx-auto mb-8 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {stats.map((stat, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-card/60 backdrop-blur-md border border-border/50 p-5 sm:p-6 rounded-3xl shadow-lg hover:border-primary/40 hover:bg-card transition-all group"
            >
              <stat.icon className="w-6 h-6 text-primary mb-4 opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all" />
              <div className="text-3xl sm:text-4xl font-black text-foreground mb-1">{stat.value}</div>
              <div className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">{stat.label}</div>
              <div className="text-xs text-primary/70 mt-2 font-medium">{stat.sub}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* GET NUMBER Button */}
      <section className="px-4 max-w-6xl mx-auto mb-8 relative z-10">
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          onClick={() => setShowGetNumber(true)}
          className="w-full py-5 rounded-2xl font-black text-xl tracking-widest uppercase flex items-center justify-center gap-3 relative overflow-hidden group shadow-[0_0_40px_rgba(6,182,212,0.25)] border border-cyan-400/30"
          style={{ background: "linear-gradient(135deg, #0e7490 0%, #06b6d4 50%, #22d3ee 100%)" }}
        >
          <motion.div
            animate={{ x: [-200, 400] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 w-32 h-full bg-white/10 blur-xl skew-x-12 pointer-events-none"
          />
          <Send className="w-6 h-6 text-white" />
          <span className="text-white drop-shadow-md">GET NUMBER</span>
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 border border-white/30 text-white text-xs font-bold ml-1">
            <motion.div
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 1.2, repeat: Infinity }}
              className="w-1.5 h-1.5 rounded-full bg-white"
            />
            LIVE
          </div>
        </motion.button>
      </section>

      {/* Live Feed Area */}
      <main className="px-4 max-w-6xl mx-auto relative z-10">
        <div className="bg-[#0b1120]/80 backdrop-blur-2xl border border-border rounded-[2rem] p-4 sm:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.4)] relative overflow-hidden">
          
          {/* Feed Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-4">
              <h2 className="text-2xl font-bold text-foreground">Live Codes Feed</h2>
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[#33aa66]/10 border border-[#33aa66]/20 text-[#33aa66] text-xs font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(51,170,102,0.15)]">
                LIVE
              </div>
            </div>
            
            <div className="flex items-center gap-3 bg-background/50 border border-border px-4 py-2 rounded-full">
              <span className="text-sm text-muted-foreground font-medium">
                <strong className="text-foreground">{otps?.length || 0}</strong> codes
              </span>
              <div className="w-px h-4 bg-border" />
              <span className="px-2 py-0.5 rounded bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-wider">encrypted</span>
              <span className="px-2 py-0.5 rounded bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-wider hidden sm:block">persistent</span>
            </div>
          </div>

          {/* Error State */}
          {isError && (
             <div className="p-4 mb-6 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-sm font-medium flex items-center justify-center">
               Connection error: Failed to fetch live data. Retrying...
             </div>
          )}

          {/* Empty / Waiting State */}
          {(!otps || otps.length === 0) && !isLoading && !isError && (
            <div className="flex flex-col items-center justify-center min-h-[300px] text-center py-12">
              <SignalBars />
              <h3 className="mt-8 text-2xl font-display font-bold text-foreground">Waiting for OTPs</h3>
              <p className="mt-2 text-muted-foreground max-w-md text-sm">
                Listening for incoming signals. New verified codes will appear here in real-time...
              </p>
            </div>
          )}

          {/* Feed List */}
          <div className="space-y-3">
            <AnimatePresence>
              {otps?.map((otp, i) => (
                <motion.div
                  key={otp.id}
                  initial={{ opacity: 0, x: -20, height: 0 }}
                  animate={{ opacity: 1, x: 0, height: "auto" }}
                  exit={{ opacity: 0, scale: 0.95, height: 0 }}
                  transition={{ delay: i * 0.05, duration: 0.3 }}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 sm:p-5 rounded-2xl bg-[#12192d] border border-border/50 shadow-sm hover:border-primary/40 hover:shadow-[0_0_20px_rgba(79,70,229,0.1)] transition-all group"
                >
                  <div className="flex items-center gap-3 sm:gap-5">
                    <div className="px-3 py-1.5 rounded-lg bg-[#33aa66]/10 text-[#33aa66] font-mono font-bold tracking-wider shadow-[0_0_10px_rgba(51,170,102,0.1)] border border-[#33aa66]/20">
                      {maskNumber(otp.number)}
                    </div>
                    <div className="text-lg font-display font-bold text-foreground group-hover:text-primary transition-colors">
                      {otp.service}
                    </div>
                    <div className="px-2 py-1 rounded border border-border bg-secondary/80 text-secondary-foreground text-[10px] font-bold uppercase tracking-wider hidden sm:block">
                      {otp.country}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between sm:justify-end gap-5">
                    <div className="text-3xl font-mono font-black text-white tracking-widest drop-shadow-[0_0_10px_rgba(255,255,255,0.3)] bg-gradient-to-br from-white to-white/70 bg-clip-text text-transparent">
                      {otp.code}
                    </div>
                    <div className="px-3 py-1 rounded-full bg-background border border-border text-xs text-muted-foreground whitespace-nowrap font-mono font-medium">
                      {format(new Date(otp.createdAt), "HH:mm:ss")}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 text-center">
        <div className="flex flex-col items-center justify-center gap-3 text-sm font-medium text-muted-foreground">
          <p>Trusted by thousands • Manual Clear Only • Real-time updates every 3 seconds</p>
          <Link href="/admin" className="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors focus:outline-none focus:ring-2 focus:ring-primary">
            <Lock className="w-4 h-4" />
          </Link>
        </div>
      </footer>

      {/* GET NUMBER Modal */}
      <AnimatePresence>
        {showGetNumber && <GetNumberModal onClose={() => setShowGetNumber(false)} />}
      </AnimatePresence>
    </div>
  );
}
