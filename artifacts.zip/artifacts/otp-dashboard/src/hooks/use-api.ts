import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import {
  useListOtps,
  useCreateOtp,
  useDeleteOtp,
  useAdminLogin,
  useGetAdminStats,
  getListOtpsQueryKey,
  getGetAdminStatsQueryKey
} from "@workspace/api-client-react";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

// ---------- Public OTP hooks ----------

export function useLiveOtps(limit = 100) {
  return useListOtps(
    { limit },
    { query: { refetchInterval: 3000 } }
  );
}

// ---------- Admin auth ----------

export function useAdminAuth() {
  const token = localStorage.getItem("adminToken");
  const login = useAdminLogin();
  
  const logout = () => {
    localStorage.removeItem("adminToken");
    window.location.href = "/";
  };
  
  return { token, login, logout };
}

// ---------- Admin CRUD ----------

export function useAdminDashboard() {
  const token = localStorage.getItem("adminToken") || "";
  const queryClient = useQueryClient();

  const stats = useGetAdminStats({
    request: { headers: { Authorization: `Bearer ${token}` } },
    query: { enabled: !!token, refetchInterval: 5000 }
  });

  const create = useCreateOtp({
    request: { headers: { Authorization: `Bearer ${token}` } },
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListOtpsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
      }
    }
  });

  const remove = useDeleteOtp({
    request: { headers: { Authorization: `Bearer ${token}` } },
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListOtpsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
      }
    }
  });

  return { stats, create, remove };
}

// ---------- Numbers (manual fetch — not code-generated) ----------

export interface NumberCountry {
  country: string;
  count: number;
}

export interface NumberEntry {
  id: number;
  number: string;
  country: string;
  createdAt: string;
  otpCode: string | null;
  otpService: string | null;
  otpAt: string | null;
}

async function apiFetch(path: string, init?: RequestInit) {
  const res = await fetch(`${BASE}/api${path}`, init);
  if (!res.ok) throw new Error(`API error ${res.status}`);
  return res.json();
}

export function useNumberCountries() {
  return useQuery<NumberCountry[]>({
    queryKey: ["numbers-countries"],
    queryFn: () => apiFetch("/numbers/countries"),
    refetchInterval: 5000,
  });
}

export function useNumbersByCountry(country: string | null) {
  return useQuery<NumberEntry[]>({
    queryKey: ["numbers", country],
    queryFn: () => apiFetch(`/numbers?country=${encodeURIComponent(country!)}`),
    enabled: !!country,
    refetchInterval: 4000,
  });
}

export function useUploadNumbers() {
  const queryClient = useQueryClient();
  const token = localStorage.getItem("adminToken") || "";

  return useMutation({
    mutationFn: async (lines: string[]) => {
      const res = await fetch(`${BASE}/api/numbers/upload`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ lines }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error((err as { error?: string }).error ?? "Upload failed");
      }
      return res.json() as Promise<{ inserted: number; skipped: number; total: number }>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["numbers-countries"] });
      queryClient.invalidateQueries({ queryKey: ["numbers"] });
    },
  });
}

// ---------- Broadcasts ----------

export interface BroadcastEntry {
  id: number;
  message: string;
  active: boolean;
  createdAt: string;
}

export function useActiveBroadcast() {
  return useQuery<BroadcastEntry | null>({
    queryKey: ["broadcast-active"],
    queryFn: () => apiFetch("/broadcasts/active"),
    refetchInterval: 5000,
  });
}

export function useSendBroadcast() {
  const queryClient = useQueryClient();
  const token = localStorage.getItem("adminToken") || "";

  return useMutation({
    mutationFn: async (message: string) => {
      const res = await fetch(`${BASE}/api/broadcasts`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ message }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error((err as { error?: string }).error ?? "Failed to send");
      }
      return res.json() as Promise<BroadcastEntry>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["broadcast-active"] });
    },
  });
}

export function useClearBroadcast() {
  const queryClient = useQueryClient();
  const token = localStorage.getItem("adminToken") || "";

  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${BASE}/api/broadcasts/${id}/dismiss`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to clear");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["broadcast-active"] });
    },
  });
}

export function useDeleteNumbersByCountry() {
  const queryClient = useQueryClient();
  const token = localStorage.getItem("adminToken") || "";

  return useMutation({
    mutationFn: async (country: string) => {
      const res = await fetch(
        `${BASE}/api/numbers/by-country?country=${encodeURIComponent(country)}`,
        { method: "DELETE", headers: { Authorization: `Bearer ${token}` } }
      );
      if (!res.ok) throw new Error("Delete failed");
      return res.json() as Promise<{ deleted: number; country: string }>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["numbers-countries"] });
      queryClient.invalidateQueries({ queryKey: ["numbers"] });
    },
  });
}

export function useDeleteNumber() {
  const queryClient = useQueryClient();
  const token = localStorage.getItem("adminToken") || "";

  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${BASE}/api/numbers/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Delete failed");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["numbers-countries"] });
      queryClient.invalidateQueries({ queryKey: ["numbers"] });
    },
  });
}
