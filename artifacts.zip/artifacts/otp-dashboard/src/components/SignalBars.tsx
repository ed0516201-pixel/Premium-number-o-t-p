import { motion } from "framer-motion";

export function SignalBars() {
  return (
    <div className="flex items-end justify-center gap-1.5 h-16">
      {[40, 70, 45, 90, 60].map((h, i) => (
        <motion.div
          key={i}
          className="w-2 rounded-full bg-primary"
          animate={{ height: ["40%", "100%", "40%"] }}
          transition={{ 
            duration: 1.2, 
            repeat: Infinity, 
            delay: i * 0.15, 
            ease: "easeInOut" 
          }}
          style={{ height: `${h}%` }}
        />
      ))}
    </div>
  );
}
