import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Loader2, ChevronDown, Phone, Clock, RefreshCw, Copy, Check } from "lucide-react";
import { useNumberCountries, useNumbersByCountry } from "@/hooks/use-api";
import { format, differenceInMinutes } from "date-fns";

interface Props {
  onClose: () => void;
}

export default function GetNumberModal({ onClose }: Props) {
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<number | null>(null);

  function copyNumber(id: number, number: string) {
    navigator.clipboard.writeText(number).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  }

  const { data: countries, isLoading: countriesLoading } = useNumberCountries();
  const { data: numbers, isLoading: numbersLoading, dataUpdatedAt } = useNumbersByCountry(selectedCountry);

  function isNew(otpAt: string | null): boolean {
    if (!otpAt) return false;
    return differenceInMinutes(new Date(), new Date(otpAt)) < 5;
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.25 }}
        className="relative z-10 w-full max-w-2xl bg-[#0b1120] border border-border rounded-3xl shadow-[0_30px_80px_rgba(0,0,0,0.6)] overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4 border-b border-border/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center">
              <Phone className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-foreground">Get Number</h2>
              <p className="text-xs text-muted-foreground">Select a country to see available numbers</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {numbersLoading && selectedCountry && (
              <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-medium">
                <RefreshCw className="w-3 h-3 animate-spin" /> Live
              </div>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-secondary/60 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          {/* Country selector */}
          <div>
            <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 block">
              Select Country
            </label>
            {countriesLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground text-sm py-3">
                <Loader2 className="w-4 h-4 animate-spin" /> Loading countries...
              </div>
            ) : !countries || countries.length === 0 ? (
              <div className="py-4 text-center text-muted-foreground text-sm bg-secondary/20 rounded-xl border border-border">
                No numbers uploaded yet. Ask an admin to upload numbers first.
              </div>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                  className="w-full flex items-center justify-between bg-background border border-border rounded-xl px-4 py-3 text-left hover:border-cyan-500/50 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all"
                >
                  <span className={selectedCountry ? "text-foreground font-medium" : "text-muted-foreground"}>
                    {selectedCountry ?? "Choose a country..."}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${dropdownOpen ? "rotate-180" : ""}`} />
                </button>

                <AnimatePresence>
                  {dropdownOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      className="absolute top-full mt-2 left-0 right-0 z-20 bg-[#0e1627] border border-border rounded-xl shadow-xl overflow-hidden max-h-60 overflow-y-auto"
                    >
                      {countries.map((c) => (
                        <button
                          key={c.country}
                          onClick={() => {
                            setSelectedCountry(c.country);
                            setDropdownOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-4 py-3 text-left hover:bg-cyan-500/10 transition-colors border-b border-border/30 last:border-0 ${selectedCountry === c.country ? "bg-cyan-500/10 text-cyan-400" : "text-foreground"}`}
                        >
                          <span className="font-medium">{c.country}</span>
                          <span className="text-xs text-muted-foreground bg-secondary/80 px-2 py-0.5 rounded-full">
                            {c.count} number{c.count !== 1 ? "s" : ""}
                          </span>
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>

          {/* Numbers list */}
          {selectedCountry && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">
                  Available Numbers
                </label>
                {dataUpdatedAt > 0 && (
                  <div className="text-xs text-muted-foreground font-mono">
                    Updated {format(new Date(dataUpdatedAt), "HH:mm:ss")}
                  </div>
                )}
              </div>

              {!numbers || numbers.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground text-sm bg-secondary/10 rounded-xl border border-border">
                  No numbers found for this country.
                </div>
              ) : (
                <div className="space-y-2">
                  <AnimatePresence>
                    {numbers.map((n) => {
                      const fresh = isNew(n.otpAt);
                      return (
                        <motion.div
                          key={n.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0 }}
                          className={`relative flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 pr-10 rounded-2xl border transition-all ${
                            n.otpCode
                              ? fresh
                                ? "bg-[#0d1f14] border-[#33aa66]/50 shadow-[0_0_25px_rgba(51,170,102,0.12)]"
                                : "bg-[#0d1f14] border-[#33aa66]/25 shadow-[0_0_15px_rgba(51,170,102,0.05)]"
                              : "bg-[#12192d] border-border/50"
                          }`}
                        >
                          <button
                            onClick={() => copyNumber(n.id, n.number)}
                            title="Copy number"
                            className="absolute top-2 right-2 p-1.5 rounded-lg bg-background/60 hover:bg-cyan-500/20 border border-border/50 hover:border-cyan-500/40 text-muted-foreground hover:text-cyan-400 transition-all"
                          >
                            {copiedId === n.id ? (
                              <Check className="w-3.5 h-3.5 text-green-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="px-3 py-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 font-mono font-bold text-base border border-cyan-500/20 whitespace-nowrap flex-shrink-0">
                              {n.number}
                            </div>
                            {n.otpService && (
                              <span className="text-sm text-muted-foreground">{n.otpService}</span>
                            )}
                            {fresh && n.otpCode && (
                              <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#33aa66]/20 border border-[#33aa66]/30">
                                <motion.div
                                  animate={{ opacity: [1, 0.3, 1] }}
                                  transition={{ duration: 0.8, repeat: Infinity }}
                                  className="w-1.5 h-1.5 rounded-full bg-[#33aa66]"
                                />
                                <span className="text-[10px] font-black uppercase tracking-wider text-[#33aa66]">NEW</span>
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-3">
                            {n.otpCode ? (
                              <>
                                <div className={`text-2xl font-mono font-black tracking-widest ${fresh ? "text-white drop-shadow-[0_0_10px_rgba(51,170,102,0.5)]" : "text-white/80"}`}>
                                  {n.otpCode}
                                </div>
                                {n.otpAt && (
                                  <div className="flex items-center gap-1 text-xs text-muted-foreground font-mono bg-background border border-border px-2 py-1 rounded-full">
                                    <Clock className="w-3 h-3" />
                                    {format(new Date(n.otpAt), "HH:mm:ss")}
                                  </div>
                                )}
                              </>
                            ) : (
                              <div className="flex items-center gap-2 text-xs text-muted-foreground bg-secondary/40 px-3 py-1.5 rounded-full border border-border">
                                <motion.div
                                  animate={{ opacity: [1, 0.3, 1] }}
                                  transition={{ duration: 1.5, repeat: Infinity }}
                                  className="w-1.5 h-1.5 rounded-full bg-yellow-500"
                                />
                                Waiting for OTP...
                              </div>
                            )}
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              )}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
