import { Router, type IRouter } from "express";
import healthRouter from "./health";
import otpsRouter from "./otps";
import numbersRouter from "./numbers";
import broadcastsRouter from "./broadcasts";

const router: IRouter = Router();

router.use(healthRouter);
router.use(otpsRouter);
router.use(numbersRouter);
router.use(broadcastsRouter);

export default router;
