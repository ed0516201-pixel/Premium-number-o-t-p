import { Router, type IRouter } from "express";

const router: IRouter = Router();

const UPSTREAM_URL = "http://147.135.212.197/crapi/st/viewstats";
const UPSTREAM_TOKEN =
  "RlZYSEJBUzRoZ5Z2RY2DdYl1anpJdndzVndrSlZPkmFTUlhXaWhPXQ==";

router.get("/otp-stats", async (_req, res) => {
  try {
    const upstream = await fetch(UPSTREAM_URL, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${UPSTREAM_TOKEN}`,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    });

    const text = await upstream.text();

    let body: unknown;
    try {
      body = JSON.parse(text);
    } catch {
      body = text;
    }

    res.status(upstream.status).json(body);
  } catch (err) {
    console.error("OTP proxy error:", err);
    res.status(502).json({ error: "Failed to reach upstream OTP service" });
  }
});

export default router;
