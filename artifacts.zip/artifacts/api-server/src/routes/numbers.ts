import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, numbersTable } from "@workspace/db";
import { detectCountry } from "../lib/country-detect";

const router: IRouter = Router();

const ADMIN_TOKEN = process.env.ADMIN_TOKEN ?? "premium-otp-secret-token";

function isAuthorized(req: { headers: Record<string, string | string[] | undefined>; body?: Record<string, unknown> }): boolean {
  const authHeader = req.headers["authorization"];
  if (authHeader && typeof authHeader === "string") {
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (token === ADMIN_TOKEN) return true;
  }
  if (req.body && req.body.adminToken === ADMIN_TOKEN) return true;
  return false;
}

// GET /numbers/countries — distinct countries that have numbers
router.get("/numbers/countries", async (_req, res): Promise<void> => {
  const rows = await db.execute(
    sql`SELECT country, COUNT(*)::int as count FROM numbers GROUP BY country ORDER BY count DESC`
  );
  res.json(rows.rows);
});

// GET /numbers?country=... — numbers for a country with latest OTP matched
router.get("/numbers", async (req, res): Promise<void> => {
  const country = typeof req.query.country === "string" ? req.query.country : null;

  // Match by exact number OR by stripping non-digit characters for flexible matching
  const rows = await db.execute(
    country
      ? sql`
          SELECT
            n.id,
            n.number,
            n.country,
            n.created_at as "createdAt",
            o.code as "otpCode",
            o.service as "otpService",
            o.created_at as "otpAt"
          FROM numbers n
          LEFT JOIN LATERAL (
            SELECT code, service, created_at
            FROM otps
            WHERE regexp_replace(number, '[^0-9]', '', 'g') = regexp_replace(n.number, '[^0-9]', '', 'g')
            ORDER BY created_at DESC
            LIMIT 1
          ) o ON true
          WHERE n.country = ${country}
          ORDER BY (o.created_at IS NOT NULL) DESC, n.created_at DESC
        `
      : sql`
          SELECT
            n.id,
            n.number,
            n.country,
            n.created_at as "createdAt",
            o.code as "otpCode",
            o.service as "otpService",
            o.created_at as "otpAt"
          FROM numbers n
          LEFT JOIN LATERAL (
            SELECT code, service, created_at
            FROM otps
            WHERE regexp_replace(number, '[^0-9]', '', 'g') = regexp_replace(n.number, '[^0-9]', '', 'g')
            ORDER BY created_at DESC
            LIMIT 1
          ) o ON true
          ORDER BY (o.created_at IS NOT NULL) DESC, n.created_at DESC
        `
  );

  res.json(rows.rows);
});

// POST /numbers/upload — bulk upload from TXT (admin only)
router.post("/numbers/upload", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { lines } = req.body as { lines?: unknown };

  if (!Array.isArray(lines) || lines.length === 0) {
    res.status(400).json({ error: "lines array is required" });
    return;
  }

  // Parse and detect country for all valid lines
  const rows: { number: string; country: string }[] = [];
  let skipped = 0;

  for (const raw of lines) {
    const num = String(raw).trim();
    if (!num || num.length < 5) { skipped++; continue; }
    rows.push({ number: num, country: detectCountry(num) });
  }

  // Bulk insert in chunks of 500, ignoring duplicates
  const CHUNK = 500;
  let inserted = 0;

  for (let i = 0; i < rows.length; i += CHUNK) {
    const chunk = rows.slice(i, i + CHUNK);
    try {
      const result = await db
        .insert(numbersTable)
        .values(chunk)
        .onConflictDoNothing()
        .returning({ id: numbersTable.id });
      inserted += result.length;
      skipped += chunk.length - result.length;
    } catch (e) {
      console.error("[upload] Chunk insert error:", e);
      skipped += chunk.length;
    }
  }

  res.json({ inserted, skipped, total: lines.length });
});

// DELETE /numbers/by-country?country=... — delete ALL numbers for a country (admin only)
router.delete("/numbers/by-country", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const country = typeof req.query.country === "string" ? req.query.country.trim() : "";
  if (!country) {
    res.status(400).json({ error: "country query param is required" });
    return;
  }

  const deleted = await db
    .delete(numbersTable)
    .where(eq(numbersTable.country, country))
    .returning({ id: numbersTable.id });

  res.json({ deleted: deleted.length, country });
});

// DELETE /numbers/:id — remove a number (admin only)
router.delete("/numbers/:id", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [deleted] = await db.delete(numbersTable).where(eq(numbersTable.id, id)).returning();
  if (!deleted) { res.status(404).json({ error: "Not found" }); return; }

  res.sendStatus(204);
});

export default router;
