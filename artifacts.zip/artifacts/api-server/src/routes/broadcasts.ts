import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, broadcastsTable } from "@workspace/db";

const router: IRouter = Router();

const ADMIN_TOKEN = process.env.ADMIN_TOKEN ?? "premium-otp-secret-token";

function isAuthorized(req: { headers: Record<string, string | string[] | undefined> }): boolean {
  const authHeader = req.headers["authorization"];
  if (authHeader && typeof authHeader === "string") {
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (token === ADMIN_TOKEN) return true;
  }
  return false;
}

// GET /broadcasts/active — latest active broadcast (public)
router.get("/broadcasts/active", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(broadcastsTable)
    .where(eq(broadcastsTable.active, true))
    .orderBy(broadcastsTable.createdAt)
    .limit(1);
  res.json(rows[0] ?? null);
});

// GET /broadcasts — all broadcasts (admin)
router.get("/broadcasts", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const rows = await db
    .select()
    .from(broadcastsTable)
    .orderBy(broadcastsTable.createdAt);
  res.json(rows);
});

// POST /broadcasts — create broadcast (admin)
router.post("/broadcasts", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const { message } = req.body as { message?: string };
  if (!message?.trim()) {
    res.status(400).json({ error: "message is required" });
    return;
  }
  // Deactivate all previous broadcasts first
  await db.update(broadcastsTable).set({ active: false });
  // Insert new one
  const [created] = await db
    .insert(broadcastsTable)
    .values({ message: message.trim(), active: true })
    .returning();
  res.json(created);
});

// DELETE /broadcasts/:id — remove broadcast (admin)
router.delete("/broadcasts/:id", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(broadcastsTable).where(eq(broadcastsTable.id, id));
  res.sendStatus(204);
});

// PATCH /broadcasts/:id/dismiss — deactivate broadcast (admin)
router.patch("/broadcasts/:id/dismiss", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [updated] = await db
    .update(broadcastsTable)
    .set({ active: false })
    .where(eq(broadcastsTable.id, id))
    .returning();
  res.json(updated ?? null);
});

export default router;
