import { Router, type IRouter } from "express";
import { desc, eq, gte, count, max, sql } from "drizzle-orm";
import { db, otpsTable, numbersTable } from "@workspace/db";

const router: IRouter = Router();

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "premium2025";
const ADMIN_TOKEN = process.env.ADMIN_TOKEN ?? "premium-otp-secret-token";

function isAuthorized(req: { headers: Record<string, string | string[] | undefined>; body?: Record<string, unknown> }): boolean {
  const authHeader = req.headers["authorization"];
  if (authHeader && typeof authHeader === "string") {
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (token === ADMIN_TOKEN) return true;
  }
  if (req.body && req.body.adminToken === ADMIN_TOKEN) return true;
  return false;
}

router.get("/otps", async (req, res): Promise<void> => {
  const rawLimit = req.query.limit;
  const limit = typeof rawLimit === "string" ? Math.min(parseInt(rawLimit, 10) || 200, 500) : 200;

  const otps = await db
    .select()
    .from(otpsTable)
    .orderBy(desc(otpsTable.createdAt))
    .limit(limit);

  res.json(otps);
});

router.post("/otps", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { number, service, code, country } = req.body as Record<string, string>;

  if (!number || !service || !code) {
    res.status(400).json({ error: "number, service, and code are required" });
    return;
  }

  const [otp] = await db
    .insert(otpsTable)
    .values({
      number,
      service,
      code,
      country: country ?? "🇧🇩 Bangladesh",
    })
    .returning();

  // Remove from numbers table so it no longer appears in Get Number
  const digitsOnly = number.replace(/\D/g, "");
  if (digitsOnly) {
    await db
      .delete(numbersTable)
      .where(sql`regexp_replace(${numbersTable.number}, '[^0-9]', '', 'g') = ${digitsOnly}`);
  }

  res.status(201).json(otp);
});

router.delete("/otps/:id", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);

  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const [deleted] = await db
    .delete(otpsTable)
    .where(eq(otpsTable.id, id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "OTP not found" });
    return;
  }

  res.sendStatus(204);
});

router.post("/admin/login", async (req, res): Promise<void> => {
  const { password } = req.body as Record<string, string>;

  if (!password || password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Invalid password" });
    return;
  }

  res.json({ token: ADMIN_TOKEN, success: true });
});

router.get("/admin/stats", async (req, res): Promise<void> => {
  if (!isAuthorized(req as Parameters<typeof isAuthorized>[0])) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const [totalResult] = await db.select({ total: count() }).from(otpsTable);
  const [todayResult] = await db
    .select({ today: count() })
    .from(otpsTable)
    .where(gte(otpsTable.createdAt, startOfDay));
  const [lastResult] = await db
    .select({ lastAddedAt: max(otpsTable.createdAt) })
    .from(otpsTable);

  res.json({
    totalOtps: totalResult?.total ?? 0,
    todayOtps: todayResult?.today ?? 0,
    lastAddedAt: lastResult?.lastAddedAt ?? null,
  });
});

export default router;
