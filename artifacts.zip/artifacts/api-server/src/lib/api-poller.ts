import { db, otpsTable, numbersTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const API_URL = process.env.EXTERNAL_API_URL ?? "http://147.135.212.197/crapi/st/viewstats";
const API_TOKEN = process.env.EXTERNAL_API_TOKEN ?? "RlZYSEJBUzRoZ5Z2RY2DdYl1anpJdndzVndrSlZPkmFTUlhXaWhPXQ==";
const POLL_INTERVAL_MS = Number(process.env.POLL_INTERVAL_MS ?? "8000");

type RawEntry = Record<string, unknown>;

function makeHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return "api_" + Math.abs(hash).toString(36);
}

function extractNumber(item: RawEntry): string {
  return String(
    item.number ?? item.phoneNumber ?? item.phone ?? item.mobile ?? item.msisdn ?? ""
  ).trim();
}

function extractCode(item: RawEntry): string {
  return String(item.code ?? item.otp ?? item.otp_code ?? item.pin ?? "").trim();
}

function extractService(item: RawEntry): string {
  return String(item.service ?? item.app ?? item.name ?? item.sender ?? "Unknown").trim();
}

function extractCountry(item: RawEntry): string {
  return String(item.country ?? item.region ?? "🇧🇩 Bangladesh").trim();
}

function extractCodeFromMessage(msg: string): string {
  // Try to extract numeric OTP from message text
  // e.g. "BC Verification code 336646 ..." → "336646"
  const m = msg.match(/\b(\d{4,8})\b/);
  return m ? m[1] : msg;
}

function parseEntries(data: unknown): RawEntry[] {
  if (!data) return [];

  let items: unknown[] = [];

  if (Array.isArray(data)) {
    items = data;
  } else if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (Array.isArray(d.codes)) items = d.codes;
    else if (Array.isArray(d.messages)) items = d.messages;
    else if (Array.isArray(d.data)) items = d.data;
    else if (Array.isArray(d.live)) items = d.live;
    else if (Array.isArray(d.otps)) items = d.otps;
    else if (Array.isArray(d.results)) items = d.results;
    else if (Array.isArray(d.items)) items = d.items;
    else if (d.number || d.phoneNumber || d.code || d.otp) items = [d];
  }

  return items.filter(Boolean).map((item) => {
    // Handle nested array format: [service, phoneNumber, message, timestamp]
    if (Array.isArray(item)) {
      const [service, number, message, createdAt] = item as string[];
      const msg = String(message ?? "");
      return {
        service: String(service ?? "Unknown"),
        number: String(number ?? ""),
        code: extractCodeFromMessage(msg),
        message: msg,
        createdAt: String(createdAt ?? new Date().toISOString()),
      };
    }
    if (typeof item === "object" && item !== null) return item as RawEntry;
    if (typeof item === "string" || typeof item === "number") {
      return { code: String(item) };
    }
    return {};
  });
}

async function fetchFromApi(): Promise<unknown> {
  const strategies = [
    { url: `${API_URL}?token=${encodeURIComponent(API_TOKEN)}`, headers: {} },
    { url: API_URL, headers: { token: API_TOKEN } },
    { url: API_URL, headers: { Authorization: `Bearer ${API_TOKEN}` } },
    { url: API_URL, headers: { "api-key": API_TOKEN } },
  ];

  for (const strategy of strategies) {
    try {
      const res = await fetch(strategy.url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          ...strategy.headers,
        },
        signal: AbortSignal.timeout(10000),
      });

      const text = await res.text();

      if (text.toLowerCase().includes("try again")) {
        console.warn("[api-poller] Rate limited, will retry next cycle");
        return null;
      }

      let parsed: unknown;
      try {
        parsed = JSON.parse(text);
      } catch {
        console.warn("[api-poller] Non-JSON response:", text.slice(0, 100));
        continue;
      }

      if (
        parsed &&
        typeof parsed === "object" &&
        "status" in parsed &&
        (parsed as Record<string, unknown>).status === "error"
      ) {
        continue;
      }

      return parsed;
    } catch {
      continue;
    }
  }

  console.warn("[api-poller] All auth strategies failed or rate limited");
  return null;
}

async function syncOtps(): Promise<void> {
  try {
    const data = await fetchFromApi();

    if (!data) return;

    const entries = parseEntries(data);
    if (entries.length === 0) {
      console.log("[api-poller] Fetched OK — 0 entries returned");
      return;
    }

    let inserted = 0;
    for (const entry of entries) {
      const number = extractNumber(entry);
      const code = extractCode(entry);
      const service = extractService(entry);
      const country = extractCountry(entry);
      const createdAt = entry.createdAt ? String(entry.createdAt) : "";

      if (!code) continue;

      // Include timestamp in hash so same code received at different times
      // is stored as a separate record (not deduped away)
      const raw = `${number}|${service}|${code}|${createdAt}`;
      const sourceHash = makeHash(raw);

      try {
        const [row] = await db
          .insert(otpsTable)
          .values({ number: number || "Unknown", service, code, country, sourceHash })
          .onConflictDoNothing()
          .returning({ id: otpsTable.id });

        if (row) {
          inserted++;
          // Remove from numbers table so it no longer appears in Get Number
          if (number) {
            const digitsOnly = number.replace(/\D/g, "");
            await db
              .delete(numbersTable)
              .where(sql`regexp_replace(${numbersTable.number}, '[^0-9]', '', 'g') = ${digitsOnly}`);
          }
        }
      } catch (e: unknown) {
        console.error("[api-poller] Insert error:", e instanceof Error ? e.message : e);
      }
    }

    if (inserted > 0) {
      console.log(`[api-poller] Synced ${inserted} new OTP(s) from ${entries.length} fetched`);
    } else {
      console.log(`[api-poller] Fetched ${entries.length} OTP(s) — all already stored`);
    }
  } catch (err) {
    console.error("[api-poller] Error during sync:", err);
  }
}

export function startApiPoller(): void {
  console.log(`[api-poller] Starting — polling ${API_URL} every ${POLL_INTERVAL_MS / 1000}s`);
  syncOtps(); // Run immediately on startup
  setInterval(syncOtps, POLL_INTERVAL_MS);
}
