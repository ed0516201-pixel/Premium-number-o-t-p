import { db, otpsTable, numbersTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { detectCountry } from "./country-detect.js";

const API_URL = process.env.EXTERNAL_API_URL ?? "http://147.135.212.197/crapi/st/viewstats";
const API_TOKEN = process.env.EXTERNAL_API_TOKEN ?? "RlZYSEJBUzRoZ5Z2RY2DdYl1anpJdndzVndrSlZPkmFTUlhXaWhPXQ==";

const BASE_INTERVAL_MS  = 15_000;   // 15s when healthy
const MAX_INTERVAL_MS   = 120_000;  // 2 min cap when rate-limited
const BACKOFF_FACTOR    = 2;

type RawEntry = Record<string, unknown>;

function makeHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return "api_" + Math.abs(hash).toString(36);
}

function extractNumber(item: RawEntry): string {
  return String(
    item.number ?? item.phoneNumber ?? item.phone ?? item.mobile ?? item.msisdn ?? ""
  ).trim();
}

function extractCode(item: RawEntry): string {
  return String(item.code ?? item.otp ?? item.otp_code ?? item.pin ?? "").trim();
}

function extractService(item: RawEntry): string {
  return String(item.service ?? item.app ?? item.name ?? item.sender ?? "Unknown").trim();
}

function extractCountry(item: RawEntry): string {
  return String(item.country ?? item.region ?? "🌐 Unknown").trim();
}

function extractCodeFromMessage(msg: string): string {
  const m = msg.match(/\b(\d{4,8})\b/);
  return m ? m[1] : msg;
}

function parseEntries(data: unknown): RawEntry[] {
  if (!data) return [];

  let items: unknown[] = [];

  if (Array.isArray(data)) {
    items = data;
  } else if (data && typeof data === "object") {
    const d = data as Record<string, unknown>;
    if (Array.isArray(d.codes))    items = d.codes;
    else if (Array.isArray(d.messages)) items = d.messages;
    else if (Array.isArray(d.data))     items = d.data;
    else if (Array.isArray(d.live))     items = d.live;
    else if (Array.isArray(d.otps))     items = d.otps;
    else if (Array.isArray(d.results))  items = d.results;
    else if (Array.isArray(d.items))    items = d.items;
    else if (d.number || d.phoneNumber || d.code || d.otp) items = [d];
  }

  return items.filter(Boolean).map((item) => {
    if (Array.isArray(item)) {
      const [service, number, message, createdAt] = item as string[];
      const msg = String(message ?? "");
      return {
        service: String(service ?? "Unknown"),
        number: String(number ?? ""),
        code: extractCodeFromMessage(msg),
        message: msg,
        createdAt: String(createdAt ?? new Date().toISOString()),
      };
    }
    if (typeof item === "object" && item !== null) return item as RawEntry;
    if (typeof item === "string" || typeof item === "number") {
      return { code: String(item) };
    }
    return {};
  });
}

// Returns the parsed data on success, "rate_limited" string on rate limit, null on hard failure
async function fetchFromApi(): Promise<unknown | "rate_limited"> {
  // Only try the query-param strategy first (most reliable).
  // Only fall back to header strategies if we get a clear "not authorised" JSON.
  const strategies = [
    { url: `${API_URL}?token=${encodeURIComponent(API_TOKEN)}`, headers: {} },
    { url: API_URL, headers: { token: API_TOKEN } },
    { url: API_URL, headers: { Authorization: `Bearer ${API_TOKEN}` } },
  ];

  for (const strategy of strategies) {
    let text: string;
    try {
      const res = await fetch(strategy.url, {
        method: "GET",
        headers: {
          Accept: "application/json",
          ...strategy.headers,
        },
        signal: AbortSignal.timeout(10_000),
      });
      text = await res.text();
    } catch {
      continue;
    }

    const lower = text.toLowerCase();

    // Rate-limited — stop immediately, do NOT try more strategies
    if (lower.includes("try again") || lower.includes("too many")) {
      return "rate_limited";
    }

    // HTML error page (e.g. 403/500 from reverse proxy)
    if (lower.startsWith("<!doctype") || lower.startsWith("<html")) {
      return "rate_limited";
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      console.warn("[api-poller] Non-JSON response:", text.slice(0, 120));
      continue;
    }

    if (parsed && typeof parsed === "object") {
      const p = parsed as Record<string, unknown>;
      const status = String(p.status ?? "").toLowerCase();
      const msg    = String(p.msg ?? p.message ?? "").toLowerCase();

      // "Not Authorized" → try next auth strategy
      if (status === "error" && (msg.includes("not authorized") || msg.includes("unauthor"))) {
        continue;
      }

      // "No Records Found" = valid empty response — stop here, treat as success
      if (status === "error" && (msg.includes("no record") || msg.includes("not found") || msg.includes("no data"))) {
        console.log("[api-poller] API: no records available yet");
        return [];
      }

      // Any other error
      if (status === "error") {
        console.warn("[api-poller] API error:", p.msg ?? p.message ?? text.slice(0, 80));
        return null;
      }
    }

    return parsed;
  }

  console.warn("[api-poller] All auth strategies failed");
  return null;
}

async function syncOtps(): Promise<boolean> {
  try {
    const data = await fetchFromApi();

    if (data === "rate_limited") return false;
    if (!data) return true; // hard failure — don't keep backing off

    const entries = parseEntries(data);
    if (entries.length === 0) {
      console.log("[api-poller] Fetched OK — 0 entries");
      return true;
    }

    let inserted = 0;
    for (const entry of entries) {
      const number     = extractNumber(entry);
      const code       = extractCode(entry);
      const service    = extractService(entry);
      const apiCountry = extractCountry(entry);
      const detected   = number ? detectCountry(number) : "🌐 Unknown";
      const country    = detected !== "🌐 Unknown" ? detected : apiCountry;
      const createdAt  = entry.createdAt ? String(entry.createdAt) : "";

      if (!code) continue;

      const raw        = `${number}|${service}|${code}|${createdAt}`;
      const sourceHash = makeHash(raw);

      try {
        const [row] = await db
          .insert(otpsTable)
          .values({ number: number || "Unknown", service, code, country, sourceHash })
          .onConflictDoNothing()
          .returning({ id: otpsTable.id });

        if (row) {
          inserted++;
          if (number) {
            const digitsOnly = number.replace(/\D/g, "");
            await db
              .delete(numbersTable)
              .where(sql`regexp_replace(${numbersTable.number}, '[^0-9]', '', 'g') = ${digitsOnly}`);
          }
        }
      } catch (e: unknown) {
        console.error("[api-poller] Insert error:", e instanceof Error ? e.message : e);
      }
    }

    if (inserted > 0) {
      console.log(`[api-poller] ✓ Synced ${inserted} new OTP(s) from ${entries.length} fetched`);
    } else {
      console.log(`[api-poller] Fetched ${entries.length} — all already stored`);
    }
    return true;
  } catch (err) {
    console.error("[api-poller] Unexpected error:", err);
    return true;
  }
}

export function startApiPoller(): void {
  let interval = BASE_INTERVAL_MS;

  async function tick() {
    const ok = await syncOtps();

    if (ok) {
      // Success or hard fail — reset to base interval
      interval = BASE_INTERVAL_MS;
    } else {
      // Rate-limited — back off exponentially
      interval = Math.min(interval * BACKOFF_FACTOR, MAX_INTERVAL_MS);
      console.warn(`[api-poller] Rate limited — backing off, next attempt in ${interval / 1000}s`);
    }

    setTimeout(tick, interval);
  }

  console.log(`[api-poller] Starting — base interval ${BASE_INTERVAL_MS / 1000}s, max ${MAX_INTERVAL_MS / 1000}s`);
  // Small initial delay so the server finishes booting before first hit
  setTimeout(tick, 3_000);
}
