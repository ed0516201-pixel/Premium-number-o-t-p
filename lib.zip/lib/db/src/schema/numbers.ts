import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";

export const numbersTable = pgTable("numbers", {
  id: serial("id").primaryKey(),
  number: text("number").notNull().unique(),
  country: text("country").notNull().default("🇧🇩 Bangladesh"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type NumberEntry = typeof numbersTable.$inferSelect;
