import express from "express";
import cors from "cors";
import type { Request, Response } from "express";
import { db, otpsTable, numbersTable, broadcastsTable } from "@workspace/db";
import { desc, eq, gte, count, max, sql } from "drizzle-orm";
import { detectCountry } from "../artifacts/api-server/src/lib/country-detect.js";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "premium2025";
const ADMIN_TOKEN = process.env.ADMIN_TOKEN ?? "premium-otp-secret-token";

const app = express();
app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

function isAuthorized(req: Request): boolean {
  const authHeader = req.headers["authorization"];
  if (authHeader && typeof authHeader === "string") {
    const token = authHeader.replace(/^Bearer\s+/i, "");
    if (token === ADMIN_TOKEN) return true;
  }
  if (req.body?.adminToken === ADMIN_TOKEN) return true;
  return false;
}

// Health
app.get("/api/health", (_req: Request, res: Response) => {
  res.json({ status: "ok" });
});

// ── OTPs ────────────────────────────────────────────────────────────────────

app.get("/api/otps", async (req: Request, res: Response): Promise<void> => {
  const rawLimit = req.query.limit;
  const limit = typeof rawLimit === "string" ? Math.min(parseInt(rawLimit, 10) || 200, 500) : 200;
  const otps = await db.select().from(otpsTable).orderBy(desc(otpsTable.createdAt)).limit(limit);
  res.json(otps);
});

app.post("/api/otps", async (req: Request, res: Response): Promise<void> => {
  if (!isAuthorized(req)) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { number, service, code, country } = req.body as Record<string, string>;
  if (!number || !service || !code) { res.status(400).json({ error: "number, service, and code are required" }); return; }
  const [otp] = await db.insert(otpsTable).values({ number, service, code, country: country ?? "🇧🇩 Bangladesh" }).returning();
  const digitsOnly = number.replace(/\D/g, "");
  if (digitsOnly) {
    await db.delete(numbersTable).where(sql`regexp_replace(${numbersTable.number}, '[^0-9]', '', 'g') = ${digitsOnly}`);
  }
  res.status(201).json(otp);
});

app.delete("/api/otps/:id", async (req: Request, res: Response): Promise<void> => {
  if (!isAuthorized(req)) { res.status(401).json({ error: "Unauthorized" }); return; }
  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [deleted] = await db.delete(otpsTable).where(eq(otpsTable.id, id)).returning();
  if (!deleted) { res.status(404).json({ error: "OTP not found" }); return; }
  res.sendStatus(204);
});

app.post("/api/admin/login", async (req: Request, res: Response): Promise<void> => {
  const { password } = req.body as Record<string, string>;
  if (!password || password !== ADMIN_PASSWORD) { res.status(401).json({ error: "Invalid password" }); return; }
  res.json({ token: ADMIN_TOKEN, success: true });
});

app.get("/api/admin/stats", async (req: Request, res: Response): Promise<void> => {
  if (!isAuthorized(req)) { res.status(401).json({ error: "Unauthorized" }); return; }
  const startOfDay = new Date(); startOfDay.setHours(0, 0, 0, 0);
  const [totalResult] = await db.select({ total: count() }).from(otpsTable);
  const [todayResult] = await db.select({ today: count() }).from(otpsTable).where(gte(otpsTable.createdAt, startOfDay));
  const [lastResult] = await db.select({ lastAddedAt: max(otpsTable.createdAt) }).from(otpsTable);
  res.json({ totalOtps: totalResult?.total ?? 0, todayOtps: todayResult?.today ?? 0, lastAddedAt: lastResult?.lastAddedAt ?? null });
});

// ── Numbers ──────────────────────────────────────────────────────────────────

app.get("/api/numbers/countries", async (_req: Request, res: Response): Promise<void> => {
  const rows = await db.execute(sql`SELECT country, COUNT(*)::int as count FROM numbers GROUP BY country ORDER BY count DESC`);
  res.json(rows.rows);
});

app.get("/api/numbers", async (req: Request, res: Response): Promise<void> => {
  const country = typeof req.query.country === "string" ? req.query.country : null;
  const rows = await db.execute(
    country
      ? sql`SELECT n.id, n.number, n.country, n.created_at as "createdAt", o.code as "otpCode", o.service as "otpService", o.created_at as "otpAt" FROM numbers n LEFT JOIN LATERAL (SELECT code, service, created_at FROM otps WHERE regexp_replace(number, '[^0-9]', '', 'g') = regexp_replace(n.number, '[^0-9]', '', 'g') ORDER BY created_at DESC LIMIT 1) o ON true WHERE n.country = ${country} ORDER BY (o.created_at IS NOT NULL) DESC, n.created_at DESC`
      : sql`SELECT n.id, n.number, n.country, n.created_at as "createdAt", o.code as "otpCode", o.service as "otpService", o.created_at as "otpAt" FROM numbers n LEFT JOIN LATERAL (SELECT code, service, created_at FROM otps WHERE regexp_replace(number, '[^0-9]', '', 'g') = regexp_replace(n.number, '[^0-9]', '', 'g') ORDER BY created_at DESC LIMIT 1) o ON true ORDER BY (o.created_at IS NOT NULL) DESC, n.created_at DESC`
  );
  res.json(rows.rows);
});

app.post("/api/numbers/upload", async (req: Request, res: Response): Promise<void> => {
  if (!isAuthorized(req)) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { lines } = req.body as { lines?: unknown };
  if (!Array.isArray(lines) || lines.length === 0) { res.status(400).json({ error: "lines array is required" }); return; }
  const rows: { number: string; country: string }[] = [];
  let skipped = 0;
  for (const raw of lines) {
    const num = String(raw).trim();
    if (!num || num.length < 5) { skipped++; continue; }
    rows.push({ number: num, country: detectCountry(num) });
  }
  const CHUNK = 500;
  let inserted = 0;
  for (let i = 0; i < rows.length; i += CHUNK) {
    const chunk = rows.slice(i, i + CHUNK);
    try {
      const result = await db.insert(numbersTable).values(chunk).onConflictDoNothing().returning({ id: numbersTable.id });
      inserted += result.length;
      skipped += chunk.length - result.length;
    } catch { skipped += chunk.length; }
  }
  res.json({ inserted, skipped, total: lines.length });
});

app.delete("/api/numbers/by-country", async (req: Request, res: Response): Promise<void> => {
  if (!isAuthorized(req)) { res.status(401).json({ error: "Unauthorized" }); return; }
  const country = typeof req.query.country === "string" ? req.query.country.trim() : "";
  if (!country) { res.status(400).json({ error: "country query param is required" }); return; }
  const deleted = await db.delete(numbersTable).where(eq(numbersTable.country, country)).returning({ id: numbersTable.id });
  res.json({ deleted: deleted.length, country });
});

app.delete("/api/numbers/:id", async (req: Request, res: Response): Promise<void> => {
  if (!isAuthorized(req)) { res.status(401).json({ error: "Unauthorized" }); return; }
  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [deleted] = await db.delete(numbersTable).where(eq(numbersTable.id, id)).returning();
  if (!deleted) { res.status(404).json({ error: "Not found" }); return; }
  res.sendStatus(204);
});

// ── Broadcasts ────────────────────────────────────────────────────────────────

app.get("/api/broadcasts/active", async (_req: Request, res: Response): Promise<void> => {
  const [row] = await db.select().from(broadcastsTable).where(eq(broadcastsTable.active, true)).orderBy(broadcastsTable.createdAt).limit(1);
  res.json(row ?? null);
});

app.post("/api/broadcasts", async (req: Request, res: Response): Promise<void> => {
  if (!isAuthorized(req)) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { message } = req.body as { message?: string };
  if (!message) { res.status(400).json({ error: "message is required" }); return; }
  await db.update(broadcastsTable).set({ active: false }).where(eq(broadcastsTable.active, true));
  const [row] = await db.insert(broadcastsTable).values({ message, active: true }).returning();
  res.status(201).json(row);
});

app.patch("/api/broadcasts/:id/dismiss", async (req: Request, res: Response): Promise<void> => {
  if (!isAuthorized(req)) { res.status(401).json({ error: "Unauthorized" }); return; }
  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.update(broadcastsTable).set({ active: false }).where(eq(broadcastsTable.id, id));
  res.sendStatus(204);
});

export default app;
